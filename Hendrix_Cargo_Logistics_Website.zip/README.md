# Hendrix Cargo & Logistics — Shipment Tracking Website

A responsive website for air freight and sea freight with a real server-backed shipment database, public tracking lookup, and a password-protected staff admin portal.

## Features
- Public tracking lookup by unique tracking number
- Shipment records stored in SQLite (persist across visits and devices when deployed on one server)
- Staff login, shipment creation, status updates, tracking event history, estimated delivery, and deletion
- Statuses: Shipment Registered, In Transit, Arrived at Destination, Customs Clearance, Out for Delivery, Delivered, On Hold
- Responsive mobile-friendly layout

## Run locally
You need Node.js 20 or newer.

1. Extract the ZIP.
2. In this project folder, copy `.env.example` to `.env`.
3. Set a long random `SESSION_SECRET` (at least 32 characters), `ADMIN_USERNAME`, and a strong `ADMIN_PASSWORD` of at least 12 characters.
4. In a terminal, run:
   ```bash
   npm install
   npm start
   ```
5. Open `http://localhost:3000`.

## How to use
- Open the homepage and select **Staff Admin Portal** in the footer.
- Sign in with the credentials you set in `.env`.
- Register a shipment and give the tracking number to the customer.
- Update the shipment status as it progresses. Customers can look up the same tracking number from any device accessing the deployed site.

## Before going live
- Deploy to a Node.js host that supports persistent storage; mount persistent storage for the `data/` folder so the SQLite database is not lost on redeploy.
- Enable HTTPS. Set `NODE_ENV=production` when HTTPS is configured.
- Use a strong unique admin password and secret; never publish your `.env` file.
- Configure a persistent session store for production rather than Express's default in-memory session store.
- Add your official business phone, WhatsApp, email, physical address, and any service-specific terms. The contact email in the page is deliberately a placeholder.
- Back up the `data/shipments.db` file regularly.
- This is a shipment status tracker updated manually by staff. It does not automatically locate cargo using airline, shipping-line, customs, GPS, or carrier APIs. Those integrations require the relevant carrier accounts and API access.
- Keep sensitive sender/receiver personal information out of public notes; this starter intentionally does not expose private customer details on the public tracking page.

## Security notes
This starter includes password-protected admin routes, login rate limiting, HTTP security headers, input validation, and session cookies. For production, use a persistent session store, HTTPS, backups, monitoring, and professional security review.
