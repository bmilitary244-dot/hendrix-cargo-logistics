require("dotenv").config();
const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const SESSION_SECRET = process.env.SESSION_SECRET;
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || "admin";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;

if (!SESSION_SECRET || SESSION_SECRET.length < 32) {
  console.error("Set SESSION_SECRET in your .env file to a random string of at least 32 characters.");
  process.exit(1);
}
if (!ADMIN_PASSWORD || ADMIN_PASSWORD.length < 12 || ADMIN_PASSWORD === "change-this-to-a-strong-password") {
  console.error("Set a strong ADMIN_PASSWORD (at least 12 characters) in your .env file.");
  process.exit(1);
}

const dataDir = path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "shipments.db"));
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS shipments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tracking_number TEXT NOT NULL UNIQUE,
    service TEXT NOT NULL CHECK(service IN ('Air Freight','Sea Freight')),
    origin TEXT NOT NULL,
    destination TEXT NOT NULL,
    status TEXT NOT NULL,
    estimated_delivery TEXT,
    public_note TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    shipment_id INTEGER NOT NULL,
    status TEXT NOT NULL,
    location TEXT DEFAULT '',
    note TEXT DEFAULT '',
    event_time TEXT NOT NULL,
    FOREIGN KEY(shipment_id) REFERENCES shipments(id) ON DELETE CASCADE
  );
`);

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: {
  directives: {
    defaultSrc: ["'self'"],
    styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
    fontSrc: ["'self'", "https://fonts.gstatic.com"],
    scriptSrc: ["'self'", "'unsafe-inline'"],
    imgSrc: ["'self'", "data:"],
    connectSrc: ["'self'"]
  }
}}));
app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));
app.use(session({
  name: "hendrix.sid",
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 2 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(__dirname, "public")));

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false });
const trackLimiter = rateLimit({ windowMs: 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false });
const statuses = ["Shipment Registered", "In Transit", "Arrived at Destination", "Customs Clearance", "Out for Delivery", "Delivered", "On Hold"];

function clean(value, max = 180) {
  return String(value ?? "").trim().slice(0, max);
}
function validDate(value) {
  if (!value) return "";
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? null : d.toISOString().slice(0, 10);
}
function adminOnly(req, res, next) {
  if (!req.session.isAdmin) return res.status(401).json({ error: "Please sign in to the admin portal." });
  next();
}
function shipmentView(row) {
  const events = db.prepare("SELECT status, location, note, event_time FROM events WHERE shipment_id=? ORDER BY id DESC").all(row.id);
  return {
    trackingNumber: row.tracking_number,
    service: row.service,
    origin: row.origin,
    destination: row.destination,
    status: row.status,
    estimatedDelivery: row.estimated_delivery || null,
    publicNote: row.public_note || "",
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    events
  };
}

app.get("/api/health", (req, res) => res.json({ ok: true, service: "Hendrix Cargo & Logistics" }));

app.post("/api/login", loginLimiter, async (req, res) => {
  const username = clean(req.body.username, 100);
  const password = String(req.body.password || "");
  const okUser = username === ADMIN_USERNAME;
  const okPassword = okUser && await bcrypt.compare(password, await bcrypt.hash(ADMIN_PASSWORD, 10)).catch(() => false);
  // Use a timing-safe hash comparison against a precomputed hash below instead.
  if (!okPassword) return res.status(401).json({ error: "Incorrect username or password." });
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "Could not start admin session." });
    req.session.isAdmin = true;
    req.session.username = ADMIN_USERNAME;
    res.json({ ok: true, username: ADMIN_USERNAME });
  });
});

app.post("/api/logout", (req, res) => {
  req.session.destroy(() => {
    res.clearCookie("hendrix.sid");
    res.json({ ok: true });
  });
});
app.get("/api/me", (req, res) => res.json({ authenticated: Boolean(req.session.isAdmin), username: req.session.username || null }));

app.get("/api/track/:trackingNumber", trackLimiter, (req, res) => {
  const tracking = clean(req.params.trackingNumber, 60).toUpperCase();
  if (!/^[A-Z0-9-]{4,60}$/.test(tracking)) return res.status(400).json({ error: "Enter a valid tracking number." });
  const row = db.prepare("SELECT * FROM shipments WHERE tracking_number=?").get(tracking);
  if (!row) return res.status(404).json({ error: "We couldn't find that tracking number. Please check it and try again." });
  res.json(shipmentView(row));
});

app.get("/api/admin/shipments", adminOnly, (req, res) => {
  const rows = db.prepare("SELECT * FROM shipments ORDER BY id DESC LIMIT 500").all();
  res.json(rows.map(r => shipmentView(r)));
});

app.post("/api/admin/shipments", adminOnly, (req, res) => {
  const trackingNumber = clean(req.body.trackingNumber, 60).toUpperCase();
  const service = clean(req.body.service, 30);
  const origin = clean(req.body.origin, 120);
  const destination = clean(req.body.destination, 120);
  const status = clean(req.body.status, 50);
  const estimatedDelivery = validDate(req.body.estimatedDelivery);
  const publicNote = clean(req.body.publicNote, 500);
  if (!/^[A-Z0-9-]{4,60}$/.test(trackingNumber)) return res.status(400).json({ error: "Tracking number must be 4–60 letters, numbers, or hyphens." });
  if (!["Air Freight", "Sea Freight"].includes(service)) return res.status(400).json({ error: "Choose Air Freight or Sea Freight." });
  if (!origin || !destination) return res.status(400).json({ error: "Origin and destination are required." });
  if (!statuses.includes(status)) return res.status(400).json({ error: "Choose a valid shipment status." });
  if (estimatedDelivery === null) return res.status(400).json({ error: "Enter a valid estimated delivery date." });
  const now = new Date().toISOString();
  try {
    const result = db.prepare(`INSERT INTO shipments (tracking_number,service,origin,destination,status,estimated_delivery,public_note,created_at,updated_at)
      VALUES (?,?,?,?,?,?,?,?,?)`).run(trackingNumber, service, origin, destination, status, estimatedDelivery, publicNote, now, now);
    db.prepare("INSERT INTO events (shipment_id,status,location,note,event_time) VALUES (?,?,?,?,?)")
      .run(result.lastInsertRowid, status, origin, "Shipment record created.", now);
    res.status(201).json({ ok: true, trackingNumber });
  } catch (e) {
    if (String(e.message).includes("UNIQUE")) return res.status(409).json({ error: "That tracking number already exists." });
    res.status(500).json({ error: "Could not create shipment." });
  }
});

app.patch("/api/admin/shipments/:trackingNumber", adminOnly, (req, res) => {
  const tracking = clean(req.params.trackingNumber, 60).toUpperCase();
  const row = db.prepare("SELECT * FROM shipments WHERE tracking_number=?").get(tracking);
  if (!row) return res.status(404).json({ error: "Shipment not found." });
  const status = clean(req.body.status, 50);
  const location = clean(req.body.location, 120);
  const note = clean(req.body.note, 500);
  const estimatedDelivery = req.body.estimatedDelivery === undefined ? row.estimated_delivery : validDate(req.body.estimatedDelivery);
  const publicNote = req.body.publicNote === undefined ? row.public_note : clean(req.body.publicNote, 500);
  if (!statuses.includes(status)) return res.status(400).json({ error: "Choose a valid shipment status." });
  if (estimatedDelivery === null) return res.status(400).json({ error: "Enter a valid estimated delivery date." });
  const now = new Date().toISOString();
  db.prepare("UPDATE shipments SET status=?,estimated_delivery=?,public_note=?,updated_at=? WHERE id=?")
    .run(status, estimatedDelivery, publicNote, now, row.id);
  db.prepare("INSERT INTO events (shipment_id,status,location,note,event_time) VALUES (?,?,?,?,?)")
    .run(row.id, status, location, note, now);
  res.json({ ok: true });
});

app.delete("/api/admin/shipments/:trackingNumber", adminOnly, (req, res) => {
  const tracking = clean(req.params.trackingNumber, 60).toUpperCase();
  db.prepare("DELETE FROM shipments WHERE tracking_number=?").run(tracking);
  res.json({ ok: true });
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`Hendrix Cargo & Logistics running on port ${PORT}`));
